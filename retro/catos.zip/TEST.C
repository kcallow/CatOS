#include <stdio.h>

int main(void) {
	int n, m, i;
	scanf("%d", &n);
	scanf("%d", &m);
	printf("n + m = %d", n + m);
	for (i = 0; i < m; i++) {
		printf("%d", i);
	}
	return 0;
}
