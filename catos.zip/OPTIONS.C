#include <stdio.h>

int main(void) {
	printf(" ");
	putchar(27);
	printf("[0;30;41m[1 DOS]");
	putchar(27);
	printf("[0m\t\t");
	putchar(27);
	printf("[30;42m[2 INFOPAD]");
	putchar(27);
	printf("[0m\t\t");
	putchar(27);
	printf("[30;43m[3 TELEMATE]");
	putchar(27);
	printf("[0m\t\t");
	putchar(27);
	printf("[30;44m[4 VI]\n");
	putchar(27);
	printf("[0m");
	printf("\n\t\t      Press a number key to start CatOS...\n\n\t\t\t\t    ");
	putchar(27);
	printf("[0;37m");
	return 0;
}
