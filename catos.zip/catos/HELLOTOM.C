#include <stdio.h>

int main(void){
	printf("Hello Tomo!!!!");
	return 0;
}
