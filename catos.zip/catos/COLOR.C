#include <stdio.h>

int main(void) {
	putchar(27);
	printf("[0;37m");
	return 0;
}
