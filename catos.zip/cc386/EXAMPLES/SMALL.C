/*
 * This demo shows how to make a minimal program by pre-defining stuff
 * that is normally dragged in from the libraries.  These definitions are
 * sufficient to bring the code size down to the smallest possible value,
 * which is around 15K, at the expense of not being able to work with
 * the command line or environment.  Use of any library functions
 * will bring the code size back up, especially if the function does
 * anything to do with malloc or any kind of input or output function.
 *
 * Without these declarations the code size for an empty main() is about
 * 28K.
 */
int _argv,_argc,_environ,_stklen = 20000;
main()
{
}